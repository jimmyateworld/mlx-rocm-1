// Copyright © 2023-2024 Apple Inc.

#pragma once

#include <metal_integer>
#include <metal_math>

#include "mlx/backend/metal/kernels/cexpf.h"
#include "mlx/backend/metal/kernels/erf.h"
#include "mlx/backend/metal/kernels/expm1f.h"
#include "mlx/backend/metal/kernels/fp8.h"

namespace {
constant float inf = metal::numeric_limits<float>::infinity();
}

struct Abs {
  template <typename T>
  T operator()(T x) thread {
    return metal::abs(x);
  };
  uint8_t operator()(uint8_t x) thread {
    return x;
  };
  uint16_t operator()(uint16_t x) thread {
    return x;
  };
  uint32_t operator()(uint32_t x) thread {
    return x;
  };
  uint64_t operator()(uint64_t x) thread {
    return x;
  };
  bool operator()(bool x) thread {
    return x;
  };
  complex64_t operator()(complex64_t x) thread {
    return {hypot(x.real, x.imag), 0};
  };
};

struct ArcCos {
  template <typename T>
  T operator()(T x) thread {
    return metal::precise::acos(x);
  };

  complex64_t operator()(complex64_t x) thread;
};

struct ArcCosh {
  template <typename T>
  T operator()(T x) thread {
    return metal::precise::acosh(x);
  };
};

struct ArcSin {
  template <typename T>
  T operator()(T x) thread {
    return metal::precise::asin(x);
  };

  complex64_t operator()(complex64_t x) thread;
};

struct ArcSinh {
  template <typename T>
  T operator()(T x) thread {
    return metal::precise::asinh(x);
  };
};

struct ArcTan {
  template <typename T>
  T operator()(T x) thread {
    return metal::precise::atan(x);
  };

  complex64_t operator()(complex64_t x) thread;
};

struct ArcTanh {
  template <typename T>
  T operator()(T x) thread {
    return metal::precise::atanh(x);
  };
};

struct BitwiseInvert {
  template <typename T>
  T operator()(T x) thread {
    return ~x;
  };
};

struct Ceil {
  template <typename T>
  T operator()(T x) thread {
    return metal::ceil(x);
  };
  int8_t operator()(int8_t x) thread {
    return x;
  };
  int16_t operator()(int16_t x) thread {
    return x;
  };
  int32_t operator()(int32_t x) thread {
    return x;
  };
  int64_t operator()(int64_t x) thread {
    return x;
  };
  uint8_t operator()(uint8_t x) thread {
    return x;
  };
  uint16_t operator()(uint16_t x) thread {
    return x;
  };
  uint32_t operator()(uint32_t x) thread {
    return x;
  };
  uint64_t operator()(uint64_t x) thread {
    return x;
  };
  bool operator()(bool x) thread {
    return x;
  };
};

struct Cos {
  template <typename T>
  T operator()(T x) thread {
    return metal::precise::cos(x);
  };

  complex64_t operator()(complex64_t x) thread {
    return {
        metal::precise::cos(x.real) * metal::precise::cosh(x.imag),
        -metal::precise::sin(x.real) * metal::precise::sinh(x.imag)};
  };
};

struct Cosh {
  template <typename T>
  T operator()(T x) thread {
    return metal::precise::cosh(x);
  };

  complex64_t operator()(complex64_t x) thread {
    return {
        metal::precise::cosh(x.real) * metal::precise::cos(x.imag),
        metal::precise::sinh(x.real) * metal::precise::sin(x.imag)};
  };
};

struct Conjugate {
  complex64_t operator()(complex64_t x) thread {
    return complex64_t{x.real, -x.imag};
  }
};

struct Erf {
  template <typename T>
  T operator()(T x) thread {
    return static_cast<T>(erf(static_cast<float>(x)));
  };
};

struct ErfInv {
  template <typename T>
  T operator()(T x) thread {
    return static_cast<T>(erfinv(static_cast<float>(x)));
  };
};

struct Exp {
  template <typename T>
  T operator()(T x) thread {
    return metal::precise::exp(x);
  };
  complex64_t operator()(complex64_t x) thread {
    return cexpf(x);
  }
};

struct Expm1 {
  template <typename T>
  T operator()(T x) thread {
    return static_cast<T>(expm1f(static_cast<float>(x)));
  };
};

struct Floor {
  template <typename T>
  T operator()(T x) thread {
    return metal::floor(x);
  };
  int8_t operator()(int8_t x) thread {
    return x;
  };
  int16_t operator()(int16_t x) thread {
    return x;
  };
  int32_t operator()(int32_t x) thread {
    return x;
  };
  int64_t operator()(int64_t x) thread {
    return x;
  };
  uint8_t operator()(uint8_t x) thread {
    return x;
  };
  uint16_t operator()(uint16_t x) thread {
    return x;
  };
  uint32_t operator()(uint32_t x) thread {
    return x;
  };
  uint64_t operator()(uint64_t x) thread {
    return x;
  };
  bool operator()(bool x) thread {
    return x;
  };
};

struct Imag {
  float operator()(complex64_t x) thread {
    return x.imag;
  };
};

struct Log {
  template <typename T>
  T operator()(T x) thread {
    return metal::precise::log(x);
  };

  complex64_t operator()(complex64_t x) thread {
    auto r = metal::precise::log(Abs{}(x).real);
    auto i = metal::precise::atan2(x.imag, x.real);
    return {r, i};
  };
};

struct Log2 {
  template <typename T>
  T operator()(T x) thread {
    return metal::precise::log2(x);
  };

  complex64_t operator()(complex64_t x) thread {
    auto y = Log{}(x);
    return {y.real / M_LN2_F, y.imag / M_LN2_F};
  };
};

struct Log10 {
  template <typename T>
  T operator()(T x) thread {
    return metal::precise::log10(x);
  };

  complex64_t operator()(complex64_t x) thread {
    auto y = Log{}(x);
    return {y.real / M_LN10_F, y.imag / M_LN10_F};
  };
};

struct Log1p {
  template <typename T>
  T operator()(T x) thread {
    return log1p(x);
  };
};

struct LogicalNot {
  template <typename T>
  T operator()(T x) thread {
    return !x;
  };
};

struct Negative {
  template <typename T>
  T operator()(T x) thread {
    return -x;
  };
};

struct Real {
  float operator()(complex64_t x) thread {
    return x.real;
  };
};

struct Round {
  template <typename T>
  T operator()(T x) thread {
    return metal::rint(x);
  };
  complex64_t operator()(complex64_t x) thread {
    return {metal::rint(x.real), metal::rint(x.imag)};
  };
};

struct Sigmoid {
  template <typename T>
  T operator()(T x) thread {
    auto y = 1 / (1 + metal::precise::exp(metal::abs(x)));
    return (x < 0) ? y : 1 - y;
  }
};

struct Sign {
  template <typename T>
  T operator()(T x) thread {
    return (x > T(0)) - (x < T(0));
  };
  uint32_t operator()(uint32_t x) thread {
    return x != 0;
  };
  complex64_t operator()(complex64_t x) thread {
    if (x == complex64_t(0)) {
      return x;
    }
    auto r = hypot(x.real, x.imag);
    return {x.real / r, x.imag / r};
  };
};

struct Sin {
  template <typename T>
  T operator()(T x) thread {
    return metal::precise::sin(x);
  };

  complex64_t operator()(complex64_t x) thread {
    return {
        metal::precise::sin(x.real) * metal::precise::cosh(x.imag),
        metal::precise::cos(x.real) * metal::precise::sinh(x.imag)};
  };
};

struct Sinh {
  template <typename T>
  T operator()(T x) thread {
    return metal::precise::sinh(x);
  };

  complex64_t operator()(complex64_t x) thread {
    return {
        metal::precise::sinh(x.real) * metal::precise::cos(x.imag),
        metal::precise::cosh(x.real) * metal::precise::sin(x.imag)};
  };
};

struct Square {
  template <typename T>
  T operator()(T x) thread {
    return x * x;
  };
};

struct Sqrt {
  template <typename T>
  T operator()(T x) thread {
    return metal::precise::sqrt(x);
  };

  complex64_t operator()(complex64_t x) thread {
    if (x.real == 0.0 && x.imag == 0.0) {
      return {0.0, 0.0};
    }
    auto r = Abs{}(x).real;
    auto a = metal::precise::sqrt((r + x.real) / 2.0);
    auto b_abs = metal::precise::sqrt((r - x.real) / 2.0);
    auto b = metal::copysign(b_abs, x.imag);
    return {a, b};
  };
};

struct Rsqrt {
  template <typename T>
  T operator()(T x) thread {
    return metal::precise::rsqrt(x);
  };

  complex64_t operator()(complex64_t x) thread {
    return 1.0 / Sqrt{}(x);
  }
};

struct Tan {
  template <typename T>
  T operator()(T x) thread {
    return metal::precise::tan(x);
  };

  complex64_t operator()(complex64_t x) thread {
    float tan_a = metal::precise::tan(x.real);
    float tanh_b = metal::precise::tanh(x.imag);
    float t1 = tan_a * tanh_b;
    float denom = 1. + t1 * t1;
    return {(tan_a - tanh_b * t1) / denom, (tanh_b + tan_a * t1) / denom};
  };
};

struct Tanh {
  template <typename T>
  T operator()(T x) thread {
    return metal::precise::tanh(x);
  };

  complex64_t operator()(complex64_t x) thread {
    float tanh_a = metal::precise::tanh(x.real);
    float tan_b = metal::precise::tan(x.imag);
    float t1 = tanh_a * tan_b;
    float denom = 1. + t1 * t1;
    return {(tanh_a + tan_b * t1) / denom, (tan_b - tanh_a * t1) / denom};
  };
};

complex64_t ArcCos::operator()(complex64_t x) thread {
  auto i = complex64_t{0.0, 1.0};
  auto y = Log{}(x + i * Sqrt{}(1.0 - x * x));
  return {y.imag, -y.real};
};

complex64_t ArcSin::operator()(complex64_t x) thread {
  auto i = complex64_t{0.0, 1.0};
  auto y = Log{}(i * x + Sqrt{}(1.0 - x * x));
  return {y.imag, -y.real};
};

complex64_t ArcTan::operator()(complex64_t x) thread {
  auto i = complex64_t{0.0, 1.0};
  auto ix = i * x;
  return (1.0 / complex64_t{0.0, 2.0}) * Log{}((1.0 + ix) / (1.0 - ix));
};

struct ToFP8 {
  template <typename T>
  uint8_t operator()(T f) thread {
    return fp8_e4m3(f).bits;
  }
};

struct FromFP8 {
  float operator()(uint8_t x) thread {
    return float(*(thread fp8_e4m3*)(&x));
  }
};
